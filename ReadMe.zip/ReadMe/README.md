# ReadMe – Android File Preview App

**ReadMe** is a simple, offline Android app that opens HTML, Markdown, SVG, CSS, JS, JSON, XML, and plain text files and shows their **final rendered preview**.

---

## How to build the APK

This is a complete, ready-to-build Android Studio project. Pick whichever path suits you — both produce a real, installable `app-debug.apk`.

### Option A — Android Studio (local, most reliable)

1. Install **Android Studio** (free) from https://developer.android.com/studio
2. Open Android Studio → **File → Open** → select the `ReadMe` folder
3. Wait for Gradle sync to finish (it downloads dependencies the first time)
4. Connect an Android phone (USB debugging enabled) **or** start an emulator
5. Click the green **Run** button (or press Shift+F10)
6. To generate the installable file directly:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - When finished, click **locate** → you'll find `app-debug.apk`
7. Transfer `app-debug.apk` to your phone and install it (enable "Install from unknown sources" if prompted)

### Option B — GitHub Actions (no software install, builds in the cloud)

1. Create a free GitHub account if you don't have one, and create a new **public or private repo**
2. Upload this whole `ReadMe` folder's contents to that repo (drag-and-drop works on github.com, or `git push`)
3. Go to the repo's **Actions** tab → the included `build-apk.yml` workflow runs automatically on push
4. When it finishes (a few minutes), open the completed run → download the **ReadMe-debug-apk** artifact (a zip containing `app-debug.apk`)
5. Transfer the APK to your phone and install it

---

## Project Structure

```
ReadMe/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/readme/app/
│       │   ├── MainActivity.kt
│       │   └── FilePreviewActivity.kt
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml
│           │   └── activity_file_preview.xml
│           ├── values/
│           │   ├── strings.xml
│           │   ├── colors.xml
│           │   └── themes.xml
│           └── xml/
│               └── file_paths.xml
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

---

## What the app can preview

| File type              | Behaviour                                      |
|------------------------|------------------------------------------------|
| `.html` / `.htm` / XHTML | Full rendered page (CSS + JavaScript work)    |
| `.md` / `.markdown`    | Clean Markdown → HTML rendering                |
| `.svg`                 | Vector graphics rendered                       |
| `.css` / `.js` / `.json` / `.xml` / `.py` / `.java` / `.kt` / `.c`/`.cpp` / `.go` / `.rs` / `.swift` / `.sh` / `.sql` / `.yaml` / `.txt` / etc. | Dark-theme, syntax-highlighted code view (keywords, strings, numbers, comments) with filename and detected language |
| Any other text file    | Same code view                                 |

You can also open files from other apps (file managers, share sheet, etc.).

---

## Features

- Material Design 3 (light & dark theme)
- Offline – no internet required
- Supports opening files from other apps
- Clean, modern UI
- Zoomable WebView for HTML/Markdown/SVG

---

Made with ❤️ for effortless file previews.
