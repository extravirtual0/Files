package com.readme.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private val openDocument = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                it,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            openPreview(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Handle files opened from other apps
        intent?.data?.let { openPreview(it) }

        findViewById<MaterialButton>(R.id.btnOpenFile).setOnClickListener {
            openDocument.launch(
                arrayOf(
                    "text/*",
                    "application/xhtml+xml",
                    "application/xml",
                    "image/svg+xml",
                    "application/javascript",
                    "application/json"
                )
            )
        }

        findViewById<MaterialCardView>(R.id.cardHtml).setOnClickListener {
            openDocument.launch(arrayOf("text/html", "application/xhtml+xml"))
        }
        findViewById<MaterialCardView>(R.id.cardMd).setOnClickListener {
            openDocument.launch(arrayOf("text/markdown", "text/x-markdown", "text/plain"))
        }
        findViewById<MaterialCardView>(R.id.cardCode).setOnClickListener {
            openDocument.launch(arrayOf("text/*", "application/javascript", "application/json"))
        }
    }

    private fun openPreview(uri: Uri) {
        val intent = Intent(this, FilePreviewActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(intent)
    }
}
