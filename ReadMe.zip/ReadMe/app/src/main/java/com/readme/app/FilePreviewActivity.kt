package com.readme.app

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import java.io.BufferedReader
import java.io.InputStreamReader

class FilePreviewActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_preview)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.previewRoot)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        errorText = findViewById(R.id.errorText)

        setupWebView()

        val uri = intent.data
        if (uri != null) {
            loadFile(uri)
        } else {
            showError("No file selected")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_NO_CACHE
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }
        }
    }

    private fun loadFile(uri: Uri) {
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        webView.visibility = View.VISIBLE

        try {
            val mimeType = contentResolver.getType(uri) ?: ""
            val fileName = getFileName(uri) ?: "Unknown"
            supportActionBar?.title = fileName

            val content = readFileContent(uri)

            when {
                // HTML / XHTML
                mimeType.contains("html") ||
                fileName.endsWith(".html", true) ||
                fileName.endsWith(".htm", true) ||
                fileName.endsWith(".xhtml", true) -> {
                    webView.loadDataWithBaseURL(null, content, "text/html", "UTF-8", null)
                }

                // Markdown
                mimeType.contains("markdown") ||
                fileName.endsWith(".md", true) ||
                fileName.endsWith(".markdown", true) -> {
                    val html = markdownToHtml(content)
                    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                }

                // SVG
                mimeType.contains("svg") || fileName.endsWith(".svg", true) -> {
                    webView.loadDataWithBaseURL(null, content, "image/svg+xml", "UTF-8", null)
                }

                // CSS / JS / JSON / XML / plain text → show as prettified code
                else -> {
                    val highlighted = wrapAsCode(content, fileName)
                    webView.loadDataWithBaseURL(null, highlighted, "text/html", "UTF-8", null)
                }
            }
        } catch (e: Exception) {
            showError("Could not open file:\n${e.message}")
        }
    }

    private fun readFileContent(uri: Uri): String {
        contentResolver.openInputStream(uri)?.use { input ->
            return BufferedReader(InputStreamReader(input)).readText()
        }
        throw Exception("Unable to read file")
    }

    private fun getFileName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index)
            }
        }
        return name ?: uri.lastPathSegment
    }

    private fun markdownToHtml(md: String): String {
        // Lightweight Markdown → HTML converter (enough for most previews)
        var html = md
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

        // Headers
        html = html.replace(Regex("^###### (.*)$", RegexOption.MULTILINE), "<h6>$1</h6>")
        html = html.replace(Regex("^##### (.*)$", RegexOption.MULTILINE), "<h5>$1</h5>")
        html = html.replace(Regex("^#### (.*)$", RegexOption.MULTILINE), "<h4>$1</h4>")
        html = html.replace(Regex("^### (.*)$", RegexOption.MULTILINE), "<h3>$1</h3>")
        html = html.replace(Regex("^## (.*)$", RegexOption.MULTILINE), "<h2>$1</h2>")
        html = html.replace(Regex("^# (.*)$", RegexOption.MULTILINE), "<h1>$1</h1>")

        // Bold / Italic
        html = html.replace(Regex("\\*\\*(.+?)\\*\\*"), "<strong>$1</strong>")
        html = html.replace(Regex("\\*(.+?)\\*"), "<em>$1</em>")
        html = html.replace(Regex("__(.+?)__"), "<strong>$1</strong>")
        html = html.replace(Regex("_(.+?)_"), "<em>$1</em>")

        // Code blocks
        html = html.replace(Regex("```([\\s\\S]*?)```"), "<pre><code>$1</code></pre>")
        html = html.replace(Regex("`([^`]+)`"), "<code>$1</code>")

        // Links
        html = html.replace(Regex("\\[([^\\]]+)\\]\\(([^)]+)\\)"), "<a href=\"$2\">$1</a>")

        // Lists
        html = html.replace(Regex("^- (.*)$", RegexOption.MULTILINE), "<li>$1</li>")
        html = html.replace(Regex("(?s)((?:<li>.*?</li>\\s*)+)"), "<ul>$1</ul>")

        // Paragraphs
        html = html.replace(Regex("(?m)^(?!<h|<ul|<pre|<li)(.+)$"), "<p>$1</p>")

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body { font-family: -apple-system, system-ui, sans-serif; padding: 16px; line-height: 1.6; color: #1a1a1a; background: #fff; }
                    @media (prefers-color-scheme: dark) {
                        body { background: #121212; color: #e0e0e0; }
                        a { color: #8ab4f8; }
                        code, pre { background: #2d2d2d; }
                    }
                    pre { background: #f5f5f5; padding: 12px; border-radius: 8px; overflow-x: auto; }
                    code { font-family: monospace; background: #f0f0f0; padding: 2px 6px; border-radius: 4px; }
                    pre code { background: transparent; padding: 0; }
                    h1,h2,h3 { margin-top: 1.4em; }
                    ul { padding-left: 1.4em; }
                    a { color: #1a73e8; }
                </style>
            </head>
            <body>$html</body>
            </html>
        """.trimIndent()
    }

    private fun wrapAsCode(content: String, fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val highlighted = highlightSyntax(content, ext)
        val langLabel = languageLabel(ext)

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body { margin: 0; padding: 12px; background: #1e1e1e; color: #d4d4d4; font-family: 'Consolas', 'Menlo', 'Monaco', monospace; font-size: 13px; line-height: 1.55; }
                    pre { margin: 0; white-space: pre-wrap; word-wrap: break-word; }
                    .filebar { display: flex; justify-content: space-between; align-items: center; color: #9cdcfe; margin-bottom: 12px; font-size: 12px; border-bottom: 1px solid #333; padding-bottom: 8px; }
                    .lang { color: #6a9955; text-transform: uppercase; letter-spacing: 0.5px; }
                    .kw { color: #569cd6; }
                    .str { color: #ce9178; }
                    .num { color: #b5cea8; }
                    .cm  { color: #6a9955; font-style: italic; }
                </style>
            </head>
            <body>
                <div class="filebar"><span>$fileName</span><span class="lang">$langLabel</span></div>
                <pre>$highlighted</pre>
            </body>
            </html>
        """.trimIndent()
    }

    private fun languageLabel(ext: String): String = when (ext) {
        "js", "mjs", "cjs" -> "JavaScript"
        "ts", "tsx" -> "TypeScript"
        "py" -> "Python"
        "java" -> "Java"
        "kt", "kts" -> "Kotlin"
        "c", "h" -> "C"
        "cpp", "cc", "hpp" -> "C++"
        "cs" -> "C#"
        "php" -> "PHP"
        "rb" -> "Ruby"
        "go" -> "Go"
        "swift" -> "Swift"
        "rs" -> "Rust"
        "css" -> "CSS"
        "json" -> "JSON"
        "xml" -> "XML"
        "sh", "bash" -> "Shell"
        "sql" -> "SQL"
        "yaml", "yml" -> "YAML"
        "" -> "Text"
        else -> ext.uppercase()
    }

    private fun escapeHtml(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")

    // Generic keyword set covering the most common C-like / Python-like / JVM languages,
    // so any code file gets sensible highlighting without a per-language grammar.
    private val genericKeywords = listOf(
        "if", "else", "elif", "for", "foreach", "while", "do", "switch", "case", "default",
        "break", "continue", "return", "function", "def", "fn", "class", "struct", "enum",
        "interface", "trait", "extends", "implements", "import", "from", "export", "package",
        "namespace", "using", "include", "public", "private", "protected", "static", "final",
        "const", "let", "var", "val", "void", "int", "float", "double", "long", "short",
        "boolean", "bool", "char", "string", "String", "new", "this", "self", "super", "try",
        "catch", "except", "finally", "throw", "throws", "raise", "null", "nil", "None",
        "undefined", "true", "false", "True", "False", "async", "await", "yield", "lambda",
        "with", "as", "in", "is", "not", "and", "or", "typedef", "template", "typename",
        "override", "abstract", "synchronized", "volatile", "instanceof", "delete", "NaN",
        "module", "require", "print", "echo", "fun", "object", "companion", "suspend"
    )

    private fun highlightSyntax(content: String, ext: String): String {
        val commentLine = if (ext in setOf("py", "rb", "sh", "bash", "yaml", "yml", "pl")) "#[^\n]*" else "//[^\n]*"
        val kwPattern = genericKeywords.joinToString("|")
        val pattern = Regex(
            """($commentLine)|(/\*[\s\S]*?\*/)|("(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\]|\\.)*`)|\b(\d+\.?\d*)\b|\b($kwPattern)\b"""
        )

        val sb = StringBuilder()
        var last = 0
        for (m in pattern.findAll(content)) {
            sb.append(escapeHtml(content.substring(last, m.range.first)))
            val g = m.groupValues
            when {
                g[1].isNotEmpty() -> sb.append("<span class=\"cm\">${escapeHtml(g[1])}</span>")
                g[2].isNotEmpty() -> sb.append("<span class=\"cm\">${escapeHtml(g[2])}</span>")
                g[3].isNotEmpty() -> sb.append("<span class=\"str\">${escapeHtml(g[3])}</span>")
                g[4].isNotEmpty() -> sb.append("<span class=\"num\">${escapeHtml(g[4])}</span>")
                g[5].isNotEmpty() -> sb.append("<span class=\"kw\">${escapeHtml(g[5])}</span>")
                else -> sb.append(escapeHtml(m.value))
            }
            last = m.range.last + 1
        }
        sb.append(escapeHtml(content.substring(last)))
        return sb.toString()
    }

    private fun showError(msg: String) {
        progressBar.visibility = View.GONE
        webView.visibility = View.GONE
        errorText.visibility = View.VISIBLE
        errorText.text = msg
    }
}
